# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

# This is an auto-generated file. Do not edit it.

"""
Provides Twisted version information.
"""

from twisted.python import versions
# Let's avoid conflating preveil development release versions with official
# twisted version numbers.
version = versions.Version('twisted', 160, 1, 2)
