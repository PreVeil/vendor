import base64
import os
import random

from fipscrypto import ec_key_to_public, EC_KEY_TYPE, EC_KEY_USAGE, \
    generate_ec_key, hybrid_box_decrypt, hybrid_box_encrypt, hybrid_seal, \
    hybrid_sign, hybrid_unseal, hybrid_verify
import pytest


@pytest.mark.parametrize("type, usage", [
    (EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE),
    (EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.SIGNATURE_USAGE),
    (EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE),
    (EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.SIGNATURE_USAGE),
])
def test_keygen(type, usage):
    priv, pub = generate_ec_key(type, usage)
    assert pub == ec_key_to_public(priv, type, usage)


def test_sealing():
    raw_25519_key, raw_25519_pub_key = generate_ec_key(
        EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE)

    raw_256_key, raw_256_pub_key = generate_ec_key(
        EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE)

    plaintext = base64.encodestring(
        os.urandom(1024 * 2 + random.randint(0, 1024)))
    cipher = hybrid_seal(raw_25519_pub_key, raw_256_pub_key, plaintext)

    assert plaintext == hybrid_unseal(raw_25519_key, raw_256_key, cipher)


def test_signing():
    raw_25519_key, raw_25519_pub_key = generate_ec_key(
        EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.SIGNATURE_USAGE)

    raw_256_key, raw_256_pub_key = generate_ec_key(
        EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.SIGNATURE_USAGE)

    blob = os.urandom(1024 * 2 + random.randint(0, 1024))
    signature = hybrid_sign(raw_25519_key, raw_256_key, blob)

    assert hybrid_verify(raw_25519_pub_key, raw_256_pub_key, signature, blob)
    assert hybrid_verify(
        raw_25519_pub_key, raw_256_pub_key,
        signature[:3] + b"\x00" + signature[4:],
        blob
    ) is False


def test_hybrid_public_key_authenticated_encryption():
    alice_raw_25519_key_pair = generate_ec_key(
        EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE)

    alice_raw_256_key_pair = generate_ec_key(
        EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE)

    bob_raw_25519_key_pair = generate_ec_key(
        EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE)

    bob_raw_256_key_pair = generate_ec_key(
        EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE)

    plaintext = base64.encodestring(
        os.urandom(1024 * 2 + random.randint(0, 1024)))

    ciphertext = hybrid_box_encrypt(
        (alice_raw_25519_key_pair[0], alice_raw_256_key_pair[0]),
        (bob_raw_25519_key_pair[1], bob_raw_256_key_pair[1]),
        plaintext
    )

    assert hybrid_box_decrypt(
        (bob_raw_25519_key_pair[0], bob_raw_256_key_pair[0]),
        (alice_raw_25519_key_pair[1], alice_raw_256_key_pair[1]),
        ciphertext
    ) == plaintext
