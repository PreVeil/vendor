import re

# Algorithm pulled from here
# https://blogs.msdn.microsoft.com/twistylittlepassagesallalike/2011/04/23/everyone-quotes-command-line-arguments-the-wrong-way/
def __quoteArg(arg):
    if not isinstance(arg, str):
        raise Exception("__quoteArg: arg must be a string")

    match = re.search(r'[ \t\n\v"]', arg)
    if not match:
        return arg

    quoted = '"'
    backslash_count = 0
    for char in arg:
        if char == '\\':
            backslash_count += 1
        elif char == '"':
            quoted += '\\' * (backslash_count * 2)
            quoted += '\\"'
            backslash_count = 0
        else:
            quoted += '\\' * backslash_count
            quoted += char
            backslash_count = 0
    quoted += '\\' * (backslash_count * 2)
    quoted += '"'

    return quoted

def quoteArgs(args):
    if isinstance(args, list) is False:
        raise Exception("quoteArgs: only accepts list type")

    return " ".join(map(lambda a: __quoteArg(a), args))
