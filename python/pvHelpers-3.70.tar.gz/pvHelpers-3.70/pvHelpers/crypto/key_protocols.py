class USER_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    V1 = 1
    Latest = 1

class ASYMM_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    V1 = 1
    V2 = 2
    Latest = 2

class SIGN_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    V1 = 1
    Latest = 1

class SYMM_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    Latest = 0
