#ifndef PyObjC_NULL_H
#define PyObjC_NULL_H

extern PyObject* PyObjC_NULL;
extern PyObject* PyObjCInitNULL(void);

#endif /* PyObjC_NULL_H */
