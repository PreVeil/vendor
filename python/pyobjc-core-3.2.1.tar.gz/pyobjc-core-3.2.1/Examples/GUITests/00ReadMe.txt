This directory contains a number of tests that require full GUI access. These
tests should be integrated in the unittest framework.
