.. PyObjC-Core documentation master file, created by
   sphinx-quickstart on Tue Dec 22 15:20:27 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyObjC-Core's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   tutorials/index
   typemapping
   protocols
   fsref-fsspec
   xcode
   blocks
   objc-gc
   type-wrapper
   introspecting
   serializing
   metadata/index
   api/index
   dev/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

