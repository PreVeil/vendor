"""
PyObjCTest package - unittests for the pyobjc core
"""
