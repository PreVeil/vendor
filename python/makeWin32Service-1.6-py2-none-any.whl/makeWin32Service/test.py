import unittest

from . import quoteArgs

class TestMakeWin32Service(unittest.TestCase):
    def test(self):
        self.assertEqual('1 blue "ye\\l low"', quoteArgs.quoteArgs(['1', 'blue', 'ye\\l low']))
        self.assertEqual('\\\\ok! abc\\\\\\def "abc\\\\\\\\\\\"" "abc\\\\\\"" "abc\\"" abc\\ abc\\\\', quoteArgs.quoteArgs(['\\\\ok!', 'abc\\\\\\def', 'abc\\\\"', 'abc\\"', 'abc"', 'abc\\', 'abc\\\\']))
        self.assertEqual('"\t\\\\\\\\"', quoteArgs.quoteArgs(['\t\\\\']))

if __name__ == '__main__':
    unittest.main()
