from pvHelpers.cs_client import BackendClient

# TODO
def test():
    a = BackendClient()
    a.init(u'ss')