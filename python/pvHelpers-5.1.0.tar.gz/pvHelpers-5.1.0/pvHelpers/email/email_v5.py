from ..misc import MergeDicts
from .email_v4 import EmailV4
from .email_helpers import PROTOCOL_VERSION


class EmailV5(EmailV4):
    protocol_version = PROTOCOL_VERSION.V5

    def __init__(self, *args, **kwargs):
        self._sender_mail_cid = kwargs.get("sender_mail_cid")
        super(EmailV5, self).__init__(*args, **kwargs)

    @property
    def sender_mail_cid(self):
        return self._sender_mail_cid

    def toDict(self):
        commons = super(EmailV5, self).toDict()
        return MergeDicts(commons, {"sender_mail_cid": self.sender_mail_cid})
