import calendar
import time

from ..misc import utf8Encode, utf8Decode, jloads, b64dec, \
    g_log, MergeDicts
from ..crypto import Sha256Sum
from . import PROTOCOL_VERSION, EmailException


def verifyServerMessage(user, message, private_metadata, fetchUser):
    if message["protocol_version"] == PROTOCOL_VERSION.V5:
        utf8_decode_pvm = utf8Decode(private_metadata)
        json_private_metadata = jloads(utf8_decode_pvm)
        sender_id = json_private_metadata["sender"]
        sender_key_version = message["sender_key_version"]
        signature = b64dec(message["signature"])
        canonical_str = Sha256Sum(utf8Encode(utf8_decode_pvm))
    elif message["protocol_version"] == PROTOCOL_VERSION.V4:
        sender_id = private_metadata["sender"]
        sender_key_version = private_metadata["signing_key_version"]
        signature = b64dec(private_metadata["signature"])

        block_ids = []
        for attachment in message["attachments"]:
            for block in attachment["blocks"]:
                block_ids.append(block["id"])
        for block in message["body"]["blocks"]:
            block_ids.append(block["id"])
        canonical_str = utf8Encode(u"".join(sorted(block_ids)))
    else:
        # we don't verify signature for legacy protocol versions
        return True

    verify_from = fetchUser(
        user, sender_id, key_version=sender_key_version)
    if not verify_from:
        g_log.error(
            "_verifyServerMessage: failed to get sender=%s from server" % sender_id)
        return False

    verified = verify_from.public_user_key.verify_key.verify(canonical_str, signature)
    if not verified:
        g_log.error("_verifyServerMessage: signature verification failed protocol_version={} sender={}".format(message["protocol_version"], sender_id))
        return False

    return True


def decryptAndVerifyServerMessage(user, message, key_version, user_encryption_key,
                                  mail_decrypt_key, fetchUser, crypto_url=None):
    """
        message: Server's message object
        key_version: user's key version used to wrap mail_decrypt_key
        user_encryption_key: user's private key
        mail_decrypt_key: symmetric key used to wrap email's props
        fetchUser: get the latest user info from the server
        crypto_url: if not None, it is from postlord. Then, user_encryption_key is a func handle.
    """
    if message["protocol_version"] == PROTOCOL_VERSION.V5:
        raw_private_metadata = mail_decrypt_key.decrypt(b64dec(message["private_metadata"]))
        if not verifyServerMessage(user, message, raw_private_metadata,
                                   fetchUser):
            return False, None

        decrypted_private_metadata = jloads(utf8Decode(raw_private_metadata))

        bccs = []
        if not crypto_url:
            recipients = jloads(utf8Decode(user_encryption_key.unseal(
                b64dec(message["wrapped_recipients"]))))

            if message["wrapped_bccs"]:
                bccs = jloads(utf8Decode(user_encryption_key.unseal(
                    b64dec(message["wrapped_bccs"]))))
        else:
            # from postlord
            recipients = user_encryption_key(
                user.user_id,
                key_version,
                b64dec(message["wrapped_recipients"]),
                crypto_url=crypto_url)
            recipients = jloads(utf8Decode(recipients))

            if message["wrapped_bccs"]:
                bccs = user_encryption_key(user.user_id, key_version,
                                           b64dec(message["wrapped_bccs"]),
                                           crypto_url=crypto_url)
                bccs = jloads(utf8Decode(bccs))

        # verify wrapped_recipient list

        decrypted_private_metadata["bccs"] = bccs
        return True, MergeDicts(message, {
            "body": decrypted_private_metadata["body"],
            "private_metadata": decrypted_private_metadata,
            "timestamp": calendar.timegm(time.strptime(message["timestamp"], "%Y-%m-%dT%H:%M:%S")),
            "attachments": decrypted_private_metadata["attachments"]
        })
    else:
        decrypted_private_metadata = jloads(utf8Decode(mail_decrypt_key.decrypt(b64dec(message["private_metadata"]))))
        if not verifyServerMessage(user, message, decrypted_private_metadata,
                                   fetchUser):
            return False, None

        return True, MergeDicts(message, {
            "body": MergeDicts(message["body"], {"snippet": utf8Decode(mail_decrypt_key.decrypt(b64dec(message["body"]["snippet"])))}),
            "private_metadata": decrypted_private_metadata,
            "timestamp": calendar.timegm(time.strptime(message["timestamp"], "%Y-%m-%dT%H:%M:%S")),
            "attachments": map(lambda att: MergeDicts(att, {"name": utf8Decode(mail_decrypt_key.decrypt(b64dec(att["name"])))}), message["attachments"])
        })


def getWrappedKey(server_message):
    if server_message["protocol_version"] == PROTOCOL_VERSION.V5:
        return server_message["recipient_key_version"], server_message["wrapped_key"]

    for block in server_message["body"]["blocks"]:
        return block["key_version"], block["wrapped_key"]
    for att in server_message["attachments"]:
        for block in att["blocks"]:
            return block["key_version"], block["wrapped_key"]

    raise EmailException("No wrapped key provided in server message {}".format(server_message))
