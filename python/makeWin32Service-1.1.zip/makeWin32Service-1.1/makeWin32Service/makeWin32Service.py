import win32serviceutil
import win32service
import win32event
import socket
import time
import os
import subprocess
import sys
import importlib
from distutils.sysconfig import get_python_lib

def quoteArgs(args):
    if isinstance(args, list) is False:
        raise Exception("quoteArgs: only accepts list type")

    for a in args:
        if isinstance(a, str) is False:
            raise Exception("quoteArgs: list members must be strings")
        elif '"' in a:
            raise Exception("quoteArgs: arg must not contain '\"'")

    return ("\"{}\" " * len(args)).format(*args)

# There is weirdness around environment variables and command line arguments.
# When this 'make_win32_service.py' process is started the easiest way to pass
# inputs is thru environment variables because the command line is being
# bogarted by the service handling stuff.
#
# But, the way python services work is as follows.
# win32serviceutil.InstallService adds pythonservice.exe as a Windows Service
# with the name from _svc_name_. pythonservice.exe then reloads
# `make_win32_service.py` and instantiates an instance of the class. The
# implication is that environment variables are not available when SvcDoRun is
# called. This is problematic because _svc_name_/_svc_display_name_ need to be
# set when the service is started as well as before it is installed.
#
# To get around this, we use _exe_args_ which is set before the service is
# created and then passed to the PreVeilService instantiation after the
# service is installed/started.
#
# Note that, _exe_args_ is just a string that is appended to the
# pythonservice.exe name. This means that we have to handle quoting ourselves.
# Windows makes paths with the double-quote character illegal, so use
# double-quote to wrap the arguments.
#
# Note that after a restart, the given python service will again receive the
# exact same args. This is nice because it means that the MODE won't change
# after a restart if it was originally set using the environment variable.

# Once the service is started, sys.executable points at pythonservice.exe,

SERVICE_NAME = os.environ.get("PV_SERVICE_NAME") or sys.argv[1]
MODULE_NAME = os.environ.get("PV_MODULE_NAME") or sys.argv[2]
MODULE_SEARCH_DIR = os.environ.get("PV_MODULE_SEARCH_DIR") or sys.argv[3]
if "PythonService.exe" == os.path.basename(sys.executable):
    PYSERVICE_PATH = sys.argv[4]
else:
    PYSERVICE_PATH = os.path.join(get_python_lib(), "win32", "PythonService.exe")
MODE = os.environ.get("PREVEIL_MODE")
if MODE is None:
    if len(sys.argv) >= 6:
        MODE = sys.argv[5]
    else:
        MODE = None
args = [SERVICE_NAME, MODULE_NAME, MODULE_SEARCH_DIR, PYSERVICE_PATH]
if MODE is not None:
    args.append(MODE)

def getServerModule(module_name, mode):
    if mode != None:
        os.environ["PREVEIL_MODE"] = mode

    sys.path = [MODULE_SEARCH_DIR] + sys.path
    return importlib.import_module(module_name)

class PreVeilService(win32serviceutil.ServiceFramework):
    _svc_name_         = SERVICE_NAME
    _svc_display_name_ = "PreVeil ({})".format(SERVICE_NAME)
    _exe_args_         = quoteArgs(args)
    # If the PythonService.exe path isn't explicilty stated, win32serviceutil
    # will look up the path using the registry, this will likely find the
    # systemwide python installation.
    _exe_name_         = PYSERVICE_PATH

    def __init__(self,args):
        server_module = getServerModule(MODULE_NAME, MODE)
        self.server   = server_module.newServer(windows_service=True)

        self.args = args
        win32serviceutil.ServiceFramework.__init__(self,args)
        self.stop_event = win32event.CreateEvent(None,0,0,None)
        socket.setdefaulttimeout(60)
        self.stop_requested = False

    def SvcStop(self):
        self.server.stop()

        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        self.stop_requested = True

    def SvcDoRun(self):
        self.server.start()

        self.ReportServiceStatus(win32service.SERVICE_RUNNING)
