import win32serviceutil
import win32service
import win32event
import socket
import time
import os
import sys
import argparse
import importlib
from distutils.sysconfig import get_python_lib

from . import quoteArgs

# There is weirdness around environment variables and command line arguments.
# When this 'make_win32_service.py' process is started the easiest way to pass
# inputs is thru environment variables because the command line is being
# bogarted by the service handling stuff.
#
# But, the way python services work is as follows.
# win32serviceutil.InstallService adds pythonservice.exe as a Windows Service
# with the name from _svc_name_. pythonservice.exe then reloads
# `make_win32_service.py` and instantiates an instance of the class. The
# implication is that environment variables are not available when SvcDoRun is
# called. This is problematic because _svc_name_/_svc_display_name_ need to be
# set when the service is started as well as before it is installed.
#
# To get around this, we use _exe_args_ which is set before the service is
# created and then passed to the PreVeilService instantiation after the
# service is installed/started.
#
# Note that, _exe_args_ is just a string that is appended to the
# pythonservice.exe name. This means that we have to handle quoting ourselves.
# Windows makes paths with the double-quote character illegal, so use
# double-quote to wrap the arguments.
#
# Note that after a restart, the given python service will again receive the
# exact same args. This is nice because it means that the MODE won't change
# after a restart if it was originally set using the environment variable.

# Once the service is started, sys.executable points at pythonservice.exe,

parser = argparse.ArgumentParser()
parser.add_argument('service_name', help="name for Windows' service")
parser.add_argument('module_name', help="python module to run")
parser.add_argument('module_search_dir', help="directory to search for python module")
parser.add_argument('pyservice_path', help="path to PythonService.exe (for internal use only)")
parser.add_argument('--preveil_mode', default=None, help="preveil mode")
parser.add_argument('--libsodium_path', default=None, help="path to libsodium dll")

if "PythonService.exe" != os.path.basename(sys.executable):
    # Service installation
    SERVICE_NAME = os.environ.get("PV_SERVICE_NAME")
    MODULE_NAME = os.environ.get("PV_MODULE_NAME")
    MODULE_SEARCH_DIR = os.environ.get("PV_MODULE_SEARCH_DIR")
    PYSERVICE_PATH = os.path.join(get_python_lib(), "win32", "PythonService.exe")
    MODE = os.environ.get("PREVEIL_MODE")
    LIBSODIUM_PATH = os.environ.get("PV_LIBSODIUM_PATH")
else:
    # Service startup
    parsed = parser.parse_args()

    SERVICE_NAME = parsed.service_name
    MODULE_NAME = parsed.module_name
    MODULE_SEARCH_DIR = parsed.module_search_dir
    PYSERVICE_PATH = parsed.pyservice_path
    MODE = parsed.preveil_mode
    LIBSODIUM_PATH = parsed.libsodium_path

argv_list = [SERVICE_NAME, MODULE_NAME, MODULE_SEARCH_DIR, PYSERVICE_PATH]
if MODE is not None:
    argv_list += ['--preveil_mode', MODE]

if LIBSODIUM_PATH is not None:
    argv_list += ['--libsodium_path', LIBSODIUM_PATH]

def getServerModule(module_name, mode, libsodium_path):
    if mode != None:
        os.environ["PREVEIL_MODE"] = mode

    if libsodium_path != None:
        os.environ['LIBSODIUM_PATH'] = libsodium_path

    sys.path = [MODULE_SEARCH_DIR] + sys.path
    return importlib.import_module(module_name)

class PreVeilService(win32serviceutil.ServiceFramework):
    _svc_name_         = SERVICE_NAME
    _svc_display_name_ = "PreVeil ({})".format(SERVICE_NAME)
    _exe_args_         = quoteArgs.quoteArgs(argv_list)
    # If the PythonService.exe path isn't explicilty stated, win32serviceutil
    # will look up the path using the registry, this will likely find the
    # systemwide python installation.
    _exe_name_         = PYSERVICE_PATH

    def __init__(self,args):
        server_module = getServerModule(MODULE_NAME, MODE, LIBSODIUM_PATH)
        self.server   = server_module.newServer(windows_service=True)

        self.args = args
        win32serviceutil.ServiceFramework.__init__(self,args)
        self.stop_event = win32event.CreateEvent(None,0,0,None)
        socket.setdefaulttimeout(60)
        self.stop_requested = False

    def SvcStop(self):
        # We do not support soft stops. The service process must be killed.
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        self.stop_requested = True

    def SvcDoRun(self):
        self.server.start()

        self.ReportServiceStatus(win32service.SERVICE_RUNNING)
