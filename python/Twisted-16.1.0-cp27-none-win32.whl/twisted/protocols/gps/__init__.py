"""Global Positioning System protocols."""
