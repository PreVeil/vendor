"""Mice Protocols."""
