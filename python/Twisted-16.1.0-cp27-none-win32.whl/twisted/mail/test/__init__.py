"Tests for twistd.mail"
