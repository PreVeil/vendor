"""News Tests"""
