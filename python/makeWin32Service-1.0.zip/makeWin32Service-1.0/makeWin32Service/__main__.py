import win32serviceutil

from . import makeWin32Service

win32serviceutil.HandleCommandLine(makeWin32Service.PreVeilService)