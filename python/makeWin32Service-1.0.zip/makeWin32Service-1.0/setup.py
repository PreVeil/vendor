from distutils.core import setup
setup(name='makeWin32Service',
      version='1.0',
      packages=['makeWin32Service'],
      install_requires=[
        "pyWin32Wrapper==1.0"
      ],
      dependency_links=[
        "https://github.com/PreVeil/vendor/raw/master/python/pyWin32Wrapper-1.0.zip"
      ]
)
