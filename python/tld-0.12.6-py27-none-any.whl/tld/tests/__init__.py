# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import unittest
from .test_core import *
from .test_commands import *
if (__name__ == u'__main__'):
    unittest.main()
