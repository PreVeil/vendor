Credits
=======
Authors
-------
- Artur Barseghyan

Contributors
------------
See the full list of contributors on `GitHub
<https://github.com/barseghyanartur/tld/graphs/contributors>`_.
