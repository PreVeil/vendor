class USER_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    Latest = 0

class ASYMM_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    Latest = 0

class SIGNER_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    Latest = 0

class SYMM_KEY_PROTOCOL_VERSION(object):
    V0 = 0
    Latest = 0
