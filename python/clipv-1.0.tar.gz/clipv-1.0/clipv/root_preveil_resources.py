from .util import GET, PUT

# TODO: complete these specs
class RootOrPreveilResources(object):
    @staticmethod
    def cryptoGetOpaqueKey():
        url = "/get/crypto/opaqueKey"
        return PUT(url, None)
