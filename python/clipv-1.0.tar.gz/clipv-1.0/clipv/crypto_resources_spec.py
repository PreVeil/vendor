import inspect, types
from .public_resources import PublicResources
from .root_preveil_resources import RootOrPreveilResources
from .test_resources import TestResources
from .user_resources import UserResources

class CryptoResourcesSpec(object):
    __classes__ = (PublicResources,
                   RootOrPreveilResources,
                   UserResources,
                   TestResources)

    @classmethod
    def spec(cls):
        ret = {}
        for c in cls.__classes__:
            for r in inspect.getmembers(c):
                if isinstance(r[1], types.FunctionType):
                    name = c.__name__ + "." + r[0]
                    ret[name] = {
                        "name": name,
                        "handle": cls.request,
                        "spec": inspect.getargspec(cls.request),
                        "rhandle": r[1],
                        "rspec": inspect.getargspec(r[1])
                    }
        return ret

    @classmethod
    def request(cls, protocol, host, port, resource_name, *args, **kwargs):
        url_base = "{}://{}:{}".format(protocol, host, port)
        resource_handle = cls.spec()[resource_name]["rhandle"]
        return resource_handle(*args, **kwargs)(url_base)


if __name__ == "__main__":
    print CryptoResourcesSpec.spec()
