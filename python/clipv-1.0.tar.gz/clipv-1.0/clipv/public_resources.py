from .util import GET, PUT

# TODO: complete these specs
class PublicResources(object):
    @staticmethod
    def ping():
        url = "/ping"
        return GET(url, None)

    @staticmethod
    def localListUsers():
        url = "/get/accounts"
        return PUT(url, None)
