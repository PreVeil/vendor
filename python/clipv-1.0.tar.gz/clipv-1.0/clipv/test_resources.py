from .util import PUT

# TODO: complete these specs
class TestResources(object):
    @staticmethod
    def testConnectionInfo():
        url = "/put/test/connection_info"
        return PUT(url, None)
