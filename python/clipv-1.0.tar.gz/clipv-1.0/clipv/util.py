import requests, types, simplejson

HEADERS = {"Content-Type": "application/json"}

def stringify_resp(resp=None, exception=None):
    if not isinstance(resp, (types.NoneType, requests.Response)):
        raise TypeError("resp must be of type requests.Response")

    if not isinstance(exception, (types.NoneType, requests.exceptions.RequestException)):
        raise TypeError("exception must be of type requests.exceptions.RequestException")
    if resp is None and exception is None:
        raise TypeError("Invalid arguments")

    return simplejson.dumps({
        "status_code": resp if resp is None else resp.status_code,
        "text": resp if resp is None else resp.text,
        "encoding": resp if resp is None else resp.encoding,
        "exception": exception if exception is None else str(exception)
    })

def PUT(resource_url, data):
    def _PUT(url_base):
        resp, exception = None, None
        try:
            resp = requests.put(url_base+resource_url, data=simplejson.dumps(data), headers=HEADERS, timeout=15, allow_redirects=False)
        except requests.exceptions.RequestException as e:
            exception = e

        return stringify_resp(resp, exception)

    return _PUT

def GET(resource_url, data):
    def _GET(url_base):
        resp, exception = None, None
        try:
            resp = requests.get(url_base+resource_url, data=data, headers=HEADERS, timeout=15, allow_redirects=False)
        except requests.exceptions.RequestException as e:
            exception = e

        return stringify_resp(resp, exception)

    return _GET
