from distutils.core import setup

setup(name="clipv",
      version="1.0",
      description="Crypto CLI",
      packages=["clipv"],
      zip_safe=False,
      install_requires=["simplejson==3.8.2"]
)
