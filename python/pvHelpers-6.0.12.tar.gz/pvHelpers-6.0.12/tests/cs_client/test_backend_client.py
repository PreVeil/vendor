from pvHelpers.cs_client import CSClient


# TODO: add cs client contract tests
def test():
    a = CSClient()
    a.init(u'ss')
