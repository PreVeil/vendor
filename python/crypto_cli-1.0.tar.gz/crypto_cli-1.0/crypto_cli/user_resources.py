from .util import PUT

# TODO: complete these specs
class UserResources(object):
    @staticmethod
    def installMuaProfile(user_id, json_body):
        url = "/post/account/{}/profile".format(user_id)
        return PUT(url, json_body)

    @staticmethod
    def fetchEmailsContent(user_id):
        url = "/mail/thread/{}".format(user_id)
        return PUT(url, None)
