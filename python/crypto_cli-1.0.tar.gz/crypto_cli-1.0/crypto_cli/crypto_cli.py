# This module imitates command line interface for crypto network resources
import requests, argparse, sys
import pvHelpers as H
from .crypto_resources_spec import CryptoResourcesSpec

def performCommand(command):
    cmd_params = {param.split("=")[0]: "=".join(param.split("=")[1:]) for param in command.parameters}
    if command.json_body != None:
        cmd_params["json_body"] = command.json_body[0]
    resource = CryptoResourcesSpec.spec()[command.resource[0]]
    r_name, r_args = resource["name"], resource["rspec"].args

    for arg in r_args:
        if arg not in cmd_params:
            raise argparse.ArgumentTypeError(u"Provided parameters/body do not match {} resource spec, missing {}".format(r_name, arg))

    result = CryptoResourcesSpec.request(command.protocol[0], command.host[0], command.port[0], r_name, **cmd_params)

    return result

def processCommand(cmd=None):
    class DummyParser(object):
        pass

    def JSONType(arg):
        status, u_arg = H.ASCIIToUnicode(arg)
        if status is False:
            raise argparse.ArgumentTypeError(u"Json argument string is not valid: {}".format(arg))
        status, _dict =  H.jloads(u_arg)
        if status == False:
            raise argparse.ArgumentTypeError(u"Json argument string is not valid: {}".format(arg))

        return _dict

    parser = argparse.ArgumentParser(description="Make requests to crypto server's resources.")
    parser.add_argument("--protocol",
                        dest="protocol",
                        choices=("http", "https", "ws", "wss"),
                        type=str,
                        nargs=1,
                        help="Crypto Server Address",
                        default=["http"])

    parser.add_argument("--host",
                        dest="host",
                        metavar=("127.0.0.1"),
                        type=str,
                        nargs=1,
                        help="Crypto Server Address",
                        default=["127.0.0.1"])

    parser.add_argument("--port",
                        dest="port",
                        metavar=(4002),
                        type=int,
                        nargs=1,
                        help="Crypto Server Port",
                        default=[2002])

    parser.add_argument("--resource",
                        dest="resource",
                        choices=(CryptoResourcesSpec.spec().keys()),
                        type=str,
                        nargs=1,
                        required=True,
                        help="Crypto Resource to be requested, see crypto_resources_spec.py")

    parser.add_argument("--query-params",
                        dest="parameters",
                        metavar=("user_id=saman@perveil.com"),
                        type=str,
                        nargs="*",
                        help="Query parameters of the specified resource. i.e. ``",
                        default=[])

    parser.add_argument("--json-body",
                        dest="json_body",
                        metavar="[1,2,3,4]",
                        type=JSONType,
                        nargs=1,
                        default=None,
                        help="JSON body content to be passed to the resource.")

    # TODO: BATCH resources tests
    # parser.add_argument("--class",
    #                     metavar=("-c"),
    #                     type=str,
    #                     nargs="*",
    #                     help="Crypto Endpoints Class, i.e. AllResourses, PublicResources",
    #                     default="AllResourses")

    result_parser = DummyParser()
    if cmd is None:
        parser.parse_args(namespace=result_parser)
    else:
        parser.parse_args(cmd.split(" "),namespace=result_parser)

    return result_parser

def handleCommand(cmd):
    return performCommand(processCommand(cmd))

def main():
    # This helpers return the result of the request in stdout
    # so that, when the scrupt is being called as a module (a process),
    # the result be accessible from stdout
    print performCommand(processCommand())
    sys.exit(0)
