from distutils.core import setup

setup(name="crypto_cli",
      version="1.0",
      description="Crypto CLI",
      packages=["crypto_cli"],
)
