# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted News: A NNTP-based news service.
"""
