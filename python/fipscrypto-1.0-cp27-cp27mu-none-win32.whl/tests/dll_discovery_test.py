import ctypes

from fipscrypto import _load_dll


def test_lib_discovery(monkeypatch):
    assert isinstance(_load_dll(), ctypes.CDLL)
