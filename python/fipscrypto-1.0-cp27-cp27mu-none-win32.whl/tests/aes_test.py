import base64
import os
import random

from fipscrypto import aes_decrypt, aes_encrypt, AES_KEY_LENGTH


def test_encryption():
    key = os.urandom(AES_KEY_LENGTH)
    plaintext = base64.encodestring(
        os.urandom(
            1024 * 1024 * random.randint(2, 5) + random.randint(0, 1024)
        )
    )
    ciphertext, tag, iv = aes_encrypt(key, plaintext)
    assert plaintext == aes_decrypt(key, ciphertext, tag, iv)
