from __future__ import print_function
from better_exceptions import color
print(color.SUPPORTS_COLOR)
