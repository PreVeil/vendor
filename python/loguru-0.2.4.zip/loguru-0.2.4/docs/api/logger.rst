loguru.logger
=============

.. autoclass:: loguru._logger.Logger()
   :members:
