API Reference
=============

..  automodule:: loguru

.. toctree::
   :includehidden:

   api/logger.rst
