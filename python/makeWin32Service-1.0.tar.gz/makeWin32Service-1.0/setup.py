from distutils.core import setup
setup(name='makeWin32Service',
      version='1.0',
      packages=['makeWin32Service'],
      install_requires=[
        "pywin32-wrapper==1.0"
      ],
      dependency_links=[
        "https://github.com/PreVeil/pywin32-wrapper/archive/master.zip#egg=pywin32-wrapper-1.0"
      ]
)
