import ctypes
import os
import sys

PACKAGE_ROOT = os.path.dirname(os.path.abspath(__file__))


def _libext():
    if sys.platform == "win32":
        return ".dll"
    if sys.platform == "darwin":
        return ".dylib"
    if sys.platform == "linux2":
        return ".so"


def _load_dll():
    if os.environ.get("PV_FIPS_CRYPTO_LIB") is not None:
        return ctypes.cdll.LoadLibrary(os.environ.get("PV_FIPS_CRYPTO_LIB"))
    else:
        libname = 'libfips-crypto' + _libext()
        return ctypes.cdll.LoadLibrary(os.path.join(PACKAGE_ROOT, libname))


PV_CRYPTO = _load_dll()

IV_LENGTH = ctypes.c_int.in_dll(PV_CRYPTO, "AesIvLength").value
AES_KEY_LENGTH = ctypes.c_int.in_dll(PV_CRYPTO, "AesKeyLength").value
AES_TAG_LENGTH = ctypes.c_int.in_dll(PV_CRYPTO, "AesTagLen").value

EC_PRIVATE_KEY_LENGTH = ctypes.c_int.in_dll(
    PV_CRYPTO, "EcPrivateKeyLength").value
CURVE25519_PUB_KEY_LENGTH = ctypes.c_int.in_dll(
    PV_CRYPTO, "Curve25519PubKeyLength").value
NISTP256_PUB_KEY_LENGTH = ctypes.c_int.in_dll(
    PV_CRYPTO, "P256PubKeyLength").value

AES_BLOCK_SIZE = 16
RAW_ECDSA_SIGNATURE_LENGTH = 64
ED25519_SIGNATURE_LENGTH = 64
HYBRID_SIGNATURE_LENGTH = RAW_ECDSA_SIGNATURE_LENGTH + ED25519_SIGNATURE_LENGTH

AES_REF = EC_KEY_REF = ctypes.c_void_p
PV_CRYPTO.aes_encrypt_init.restype = AES_REF
PV_CRYPTO.aes_encrypt_init_with_iv.restype = AES_REF
PV_CRYPTO.aes_decrypt_init.restype = AES_REF
PV_CRYPTO.generate_ec_key.restype = EC_KEY_REF
PV_CRYPTO.ec_key_from_binary.restype = EC_KEY_REF
PV_CRYPTO.fips_crypto_last_error.restype = ctypes.c_char_p


class EC_KEY_TYPE(object):
    CURVE_25519 = 0
    NIST_P256 = 1


class EC_KEY_USAGE(object):
    SIGNATURE_USAGE = 0
    ENCRYPTION_USAGE = 1

class KDF_TYPE(object):
    KDF_SHA256 = 0
    KDF_FIPS = 1

class CryptoError(Exception):
    def __init__(self, e=u""):
        super(CryptoError, self).__init__(e)


def assert_success(status):
    if status != 1:
        raise CryptoError("failed with status: {}, err: {}".format(
            status, get_last_err()))
    return status


def assert_non_zero(status):
    if status == 0:
        raise CryptoError("failed with status: {}, err: {}".format(
            status, get_last_err()))
    return status


def assert_null(reference):
    if not reference:
        raise Exception("NULL ec key_ref")
    return reference


def get_last_err():
    if os.environ.get("MODE") == "DEBUG":
        return PV_CRYPTO.fips_crypto_last_error()
    return u"non-debug mode"


def aes_encrypt(key, plaintext, iv=None):
    if iv is None:
        iv_buffer = ctypes.create_string_buffer(IV_LENGTH)
        ref = assert_null(PV_CRYPTO.aes_encrypt_init(key, iv_buffer))
        iv = iv_buffer.raw
    else:
        ref = assert_null(PV_CRYPTO.aes_encrypt_init_with_iv(key, iv))
    out_buf = ctypes.create_string_buffer(len(plaintext) + AES_BLOCK_SIZE)
    out_len = ctypes.c_int()
    assert_success(PV_CRYPTO.aes_encrypt_update(
        ctypes.c_void_p(ref), out_buf,
        ctypes.byref(out_len),
        plaintext,
        ctypes.c_int(len(plaintext))
    ))

    pad_buf = ctypes.create_string_buffer(AES_BLOCK_SIZE)
    tag = ctypes.create_string_buffer(AES_TAG_LENGTH)
    pad_len = ctypes.c_int()
    assert_success(PV_CRYPTO.aes_encrypt_finalize(
        ctypes.c_void_p(ref), pad_buf, ctypes.byref(pad_len), tag
    ))
    ciphertext = out_buf.raw[:out_len.value] + pad_buf.raw[:pad_len.value]
    return ciphertext, tag.raw[:], iv


def aes_decrypt(key, ciphertext, tag, iv):
    out_buf = ctypes.create_string_buffer(len(ciphertext) + AES_BLOCK_SIZE)
    out_len = ctypes.c_int()
    ref = PV_CRYPTO.aes_decrypt_init(key, iv)
    assert_success(PV_CRYPTO.aes_decrypt_update(
        ctypes.c_void_p(ref), out_buf, ctypes.byref(out_len),
        ciphertext, ctypes.c_int(len(ciphertext))
    ))
    assert_success(
        PV_CRYPTO.aes_decrypt_finalize(ctypes.c_void_p(ref), tag))

    return out_buf.raw[:out_len.value]


def generate_ec_key(type, usage):
    key_ref = None
    try:
        key_ref = assert_null(PV_CRYPTO.generate_ec_key(type, usage))
        bytes_ = ctypes.create_string_buffer(EC_PRIVATE_KEY_LENGTH)
        assert_success(PV_CRYPTO.ec_key_to_binary(
            ctypes.c_void_p(key_ref), type, bytes_,
            EC_PRIVATE_KEY_LENGTH, ctypes.c_bool(True)
        ))
        pub_len = CURVE25519_PUB_KEY_LENGTH if \
            type == EC_KEY_TYPE.CURVE_25519 else \
            NISTP256_PUB_KEY_LENGTH
        pub_bytes = ctypes.create_string_buffer(pub_len)

        assert_success(PV_CRYPTO.ec_key_to_binary(
            ctypes.c_void_p(key_ref), type, pub_bytes,
            pub_len, ctypes.c_bool(False)
        ))
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(key_ref))

    return bytes_.raw[:], pub_bytes.raw[:]


def ec_key_to_public(key, type, usage):
    key_ref = None
    try:
        key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(key), EC_PRIVATE_KEY_LENGTH,
            type, usage, ctypes.c_bool(True)
        ))
        pub_len = CURVE25519_PUB_KEY_LENGTH if \
            type == EC_KEY_TYPE.CURVE_25519 else \
            NISTP256_PUB_KEY_LENGTH
        pub_bytes = ctypes.create_string_buffer(pub_len)

        assert_success(PV_CRYPTO.ec_key_to_binary(
            ctypes.c_void_p(key_ref), type, pub_bytes,
            pub_len, ctypes.c_bool(False)
        ))
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(key_ref))

    return pub_bytes.raw[:]


def hybrid_unseal(curve25519_key, nistp256_key, ciphertext, use_fips_derivation):
    curve25519_key_ref = nistp256_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        outlen = ctypes.c_int()
        plaintext = ctypes.pointer(ctypes.c_ubyte())
        kdf_type = KDF_TYPE.KDF_FIPS if use_fips_derivation else KDF_TYPE.KDF_SHA256

        assert_success(PV_CRYPTO.hybrid_decrypt(
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.create_string_buffer(ciphertext), len(ciphertext),
            ctypes.byref(plaintext), ctypes.byref(outlen),
            kdf_type,
            ctypes.c_bool(use_fips_derivation)
        ))
        ret = ctypes.string_at(plaintext, size=outlen.value)
        PV_CRYPTO.fips_crypto_free(plaintext)
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))

    return ret


def hybrid_seal(curve25519_pub, nistp256_pub, plaintext, use_fips_derivation):
    curve25519_key_ref = nistp256_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_pub),
            CURVE25519_PUB_KEY_LENGTH, EC_KEY_TYPE.CURVE_25519,
            EC_KEY_USAGE.ENCRYPTION_USAGE, ctypes.c_bool(False)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_pub), NISTP256_PUB_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(False)
        ))
        outlen = ctypes.c_int()
        ciphertext = ctypes.pointer(ctypes.c_ubyte())
        kdf_type = KDF_TYPE.KDF_FIPS if use_fips_derivation else KDF_TYPE.KDF_SHA256
        assert_success(PV_CRYPTO.hybrid_encrypt(
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.create_string_buffer(plaintext), len(plaintext),
            ctypes.byref(ciphertext), ctypes.byref(outlen),
            kdf_type,
            ctypes.c_bool(use_fips_derivation)
        ))
        ret = ctypes.string_at(ciphertext, size=outlen.value)
        PV_CRYPTO.fips_crypto_free(ciphertext)
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))

    return ret


def hybrid_sign(curve25519_key, nistp256_key, message):
    curve25519_key_ref = nistp256_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.SIGNATURE_USAGE,
            ctypes.c_bool(True)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.SIGNATURE_USAGE,
            ctypes.c_bool(True)
        ))
        if sys.version_info[0] == 2:
            signature = ctypes.create_string_buffer("", size=HYBRID_SIGNATURE_LENGTH)
        else:
            signature = ctypes.create_string_buffer(bytes(), size=HYBRID_SIGNATURE_LENGTH)
        assert_success(PV_CRYPTO.ec_sign(
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.create_string_buffer(message), len(message), signature
        ))
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))

    return signature.raw[:]


def hybrid_verify(curve25519_pub, nistp256_pub, signature, message):
    curve25519_key_ref = nistp256_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_pub),
            CURVE25519_PUB_KEY_LENGTH, EC_KEY_TYPE.CURVE_25519,
            EC_KEY_USAGE.SIGNATURE_USAGE, ctypes.c_bool(False)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_pub), NISTP256_PUB_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.SIGNATURE_USAGE,
            ctypes.c_bool(False)
        ))
        status = assert_non_zero(PV_CRYPTO.ec_verify(
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.create_string_buffer(message), len(message),
            ctypes.create_string_buffer(signature)
        ))
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))

    return status == 1


def hybrid_box_encrypt(private_pair, public_pair, plaintext, use_fips_derivation):
    curve25519_key, nistp256_key = private_pair
    curve25519_pub_key, nistp256_pub_key = public_pair
    curve25519_key_ref = nistp256_key_ref = \
        curve25519_pub_key_ref = nistp256_pub_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        curve25519_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_pub_key),
            CURVE25519_PUB_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(False)
        ))
        nistp256_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_pub_key),
            NISTP256_PUB_KEY_LENGTH, EC_KEY_TYPE.NIST_P256,
            EC_KEY_USAGE.ENCRYPTION_USAGE, ctypes.c_bool(False)
        ))
        outlen = ctypes.c_int()
        ciphertext = ctypes.pointer(ctypes.c_ubyte())
        kdf_type = KDF_TYPE.KDF_FIPS if use_fips_derivation else KDF_TYPE.KDF_SHA256
        assert_success(PV_CRYPTO.box_encrypt(
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.c_void_p(curve25519_pub_key_ref),
            ctypes.c_void_p(nistp256_pub_key_ref),
            ctypes.create_string_buffer(plaintext), len(plaintext),
            ctypes.byref(ciphertext), ctypes.byref(outlen),
            kdf_type
        ))
        ret = ctypes.string_at(ciphertext, size=outlen.value)
        PV_CRYPTO.fips_crypto_free(ciphertext)
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_pub_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_pub_key_ref))

    return ret


def hybrid_box_decrypt(private_pair, public_pair, ciphertext, use_fips_derivation):
    curve25519_key, nistp256_key = private_pair
    curve25519_pub_key, nistp256_pub_key = public_pair
    curve25519_key_ref = nistp256_key_ref = \
        curve25519_pub_key_ref = nistp256_pub_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        curve25519_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_pub_key),
            CURVE25519_PUB_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(False)
        ))
        nistp256_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_pub_key),
            NISTP256_PUB_KEY_LENGTH, EC_KEY_TYPE.NIST_P256,
            EC_KEY_USAGE.ENCRYPTION_USAGE, ctypes.c_bool(False)
        ))
        outlen = ctypes.c_int()
        plaintext = ctypes.pointer(ctypes.c_ubyte())
        kdf_type = KDF_TYPE.KDF_FIPS if use_fips_derivation else KDF_TYPE.KDF_SHA256
        assert_success(PV_CRYPTO.box_decrypt(
            ctypes.c_void_p(curve25519_pub_key_ref),
            ctypes.c_void_p(nistp256_pub_key_ref),
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            ctypes.create_string_buffer(ciphertext), len(ciphertext),
            ctypes.byref(plaintext), ctypes.byref(outlen),
            kdf_type
        ))
        ret = ctypes.string_at(plaintext, size=outlen.value)
        PV_CRYPTO.fips_crypto_free(plaintext)
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_pub_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_pub_key_ref))

    return ret


def get_ecdh_shared_key(private_pair, public_pair, use_fips_derivation):
    curve25519_key, nistp256_key = private_pair
    curve25519_pub_key, nistp256_pub_key = public_pair
    curve25519_key_ref = nistp256_key_ref = \
        curve25519_pub_key_ref = nistp256_pub_key_ref = None
    try:
        curve25519_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        nistp256_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_key), EC_PRIVATE_KEY_LENGTH,
            EC_KEY_TYPE.NIST_P256, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(True)
        ))
        curve25519_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(curve25519_pub_key),
            CURVE25519_PUB_KEY_LENGTH,
            EC_KEY_TYPE.CURVE_25519, EC_KEY_USAGE.ENCRYPTION_USAGE,
            ctypes.c_bool(False)
        ))
        nistp256_pub_key_ref = assert_null(PV_CRYPTO.ec_key_from_binary(
            ctypes.create_string_buffer(nistp256_pub_key),
            NISTP256_PUB_KEY_LENGTH, EC_KEY_TYPE.NIST_P256,
            EC_KEY_USAGE.ENCRYPTION_USAGE, ctypes.c_bool(False)
        ))
        key_len = AES_KEY_LENGTH
        key_bytes = ctypes.create_string_buffer(key_len)
        kdf_type = KDF_TYPE.KDF_FIPS if use_fips_derivation else KDF_TYPE.KDF_SHA256
        assert_success(PV_CRYPTO.box_derive_key(
            ctypes.c_void_p(curve25519_pub_key_ref),
            ctypes.c_void_p(nistp256_pub_key_ref),
            ctypes.c_void_p(curve25519_key_ref),
            ctypes.c_void_p(nistp256_key_ref),
            key_bytes,
            kdf_type
        ))
    finally:
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(curve25519_pub_key_ref))
        PV_CRYPTO.ec_key_free(ctypes.c_void_p(nistp256_pub_key_ref))

    return key_bytes.raw[:]
