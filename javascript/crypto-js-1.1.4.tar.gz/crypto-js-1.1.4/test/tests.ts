import './mocks';

import 'mocha';
import { PVCrypto, PVCryptoUsage, PVCryptoKeyType } from '../lib/pv-crypto';
import { FipsCrypto } from '../lib/fips-crypto';
import { NaclCrypto } from '../lib/nacl-crypto';
import { randomBytes, b64Decode } from '../lib/util';

const assert = require('assert'),
      MessageString = 'Hello world.',
      MessageBytes = new TextEncoder().encode(MessageString);

[NaclCrypto, FipsCrypto].forEach((crypto : PVCrypto) => {
    const label = crypto.constructor.name;
    describe(`[${label}] Symmetric Key Crypto`, () => {
        it('decryption is the inverse of encryption', (async() => {
            const key = await crypto.generateKey(PVCryptoKeyType.SYMM);
            const iv = randomBytes(crypto.ivLength);

            let [ciphertext, tag] = await crypto.symmetricEncrypt(key, iv, MessageBytes);
            assert.notEqual(ciphertext, null);
            let plaintext = await crypto.symmetricDecrypt(key, iv, tag, ciphertext);
            assert.notEqual(plaintext, null);

            assert.equal(new TextDecoder().decode(plaintext), MessageString);
        }));
    });
    describe(`[${label}] Public Key Crypto`, () => {
        it('shared secret is the same for both parties', (async() => {
            let {alice, bob} = await loadKeys(crypto, PVCryptoUsage.ENCRYPT);
            let alicesSecret = await crypto.sharedSecret(alice.secretKey, bob.publicKey);
            let bobsSecret = await crypto.sharedSecret(bob.secretKey, alice.publicKey);

            assert.deepEqual(alicesSecret, bobsSecret);
        }));
        it('box encryption is the inverse of decryption', (async() => {
            let {alice, bob} = await loadKeys(crypto, PVCryptoUsage.ENCRYPT);
            let ciphertext = await crypto.boxEncrypt(alice.secretKey, bob.publicKey, MessageBytes);
            assert.notEqual(ciphertext, null);
            let plaintext = await crypto.boxDecrypt(bob.secretKey, alice.publicKey, ciphertext);
            assert.notEqual(plaintext, null);

            assert.deepEqual(plaintext, MessageBytes);
        }));
        it('hybrid encryption is the inverse of decryption', (async() => {
            let {alice, bob} = await loadKeys(crypto, PVCryptoUsage.ENCRYPT);
            let ciphertext = await crypto.hybridEncrypt(bob.publicKey, MessageBytes);
            assert.notEqual(ciphertext, null);
            let plaintext = await crypto.hybridDecrypt(bob.secretKey, ciphertext);
            assert.notEqual(plaintext, null);

            assert.deepEqual(plaintext, MessageBytes);
        }));
        it('can verify what we sign', (async() => {
            let {alice, bob} = await loadKeys(crypto, PVCryptoUsage.SIGN);
            let signature = await crypto.sign(bob.secretKey, MessageBytes);
            assert.notEqual(signature, null);
            assert.equal(await crypto.verify(bob.publicKey, MessageBytes, signature), true);
        }));
    });
});

describe('FIPS Compatibility', () => {
    it('[ECC] decrypts externally encrypted message', (async () => {
        const ciphertext = b64Decode('kkeRyypCXvCUspodaJpn783LQyaFcq4SXxlpEKKs5TwCY2uduf0kUH6i8AQdxmjC4J5w6NDeQJTCMfp79P20jVf' +
                                              'UYD64D/Vvi3c/Z17BE9da2nG1YYpI/vK8suf0');
        const publicKey = b64Decode('fQzwbUbgCtkLqtPSwKbUDyb8r5t/MUE/df1XBcSaBj8C2gyIhQO3siOZVX4IyZU2pZKzcu0DZrlEX22JNSm4FJE=');
        const privateKey = b64Decode('gFU00ge1BKK9OrMnrer5ytodyeSSdn+CFZeelhDvIUYlZSFTZEIUfs0h0Uw6kQdghm+Hw8Zh8RDrHeYKHNRhPg==');

        let plaintext = await FipsCrypto.hybridDecrypt(privateKey, ciphertext);
        assert.deepEqual(plaintext, MessageBytes);
    }));
    it('[ECC] verifies externally signed message', (async () => {
        const signature = b64Decode('ex8ZG7Ott3Cw97AQnoMYLW7CiIsI8rigKHqVmkY0feLbHnzc7Snk9oeUcomkUx/zGGRziZRK0ghtyiJwBYvJDMMd' +
                                             'p3cxauT6zNYSmPO43lV7+LLvbuqXftSixhNkPyaC8CkOWNRTev5B9UgqhEkKMoSbTH9SZMgi3B30iB5ng9s=');
        const publicKey = b64Decode('4g6V2VWlAY2CebLJs7Bin4SKp+NBzYi7UZfttUucC3AC2+noauzdhfxK3pQ9v+ar8c6T42TzZkMFvo3LWOyOoyI=');

        assert.equal(await FipsCrypto.verify(publicKey, MessageBytes, signature), true);
    }));
    it('[AES] decrypts externally encrypted message', (async () => {
        const key = b64Decode('ee1Cl8MEOPr9/PwtjFKyJqTjebq4ws91ktyi1Evvm3k=');
        const iv = b64Decode('mGVR6O7hSJNb+cJ3');
        const ciphertext = b64Decode('QlVRmkDsID0LXCIh');
        const tag = b64Decode('i0pZIpl/69qB6mP0OoW/FQ==');

        let plaintext = await FipsCrypto.symmetricDecrypt(key, iv, tag, ciphertext);
        assert.deepEqual(plaintext, MessageBytes);
    }));
});

async function loadKeys(crypto : PVCrypto, usage: PVCryptoUsage) {
    let alice = { secretKey: await crypto.generateKey(PVCryptoKeyType.ASYMM, usage), publicKey: null };
    alice.publicKey = await crypto.publicKeyFromPrivate(alice.secretKey, usage);

    let bob = { secretKey: await crypto.generateKey(PVCryptoKeyType.ASYMM, usage), publicKey: null };
    bob.publicKey = await crypto.publicKeyFromPrivate(bob.secretKey, usage);

    return {alice, bob};
}
