import * as WebCryptoMock from 'node-webcrypto-ossl';
import { TextEncoder, TextDecoder } from 'text-encoding';

Object.defineProperties(global, {
    crypto: {
      value: new WebCryptoMock()
    },
    TextEncoder: {
      value: TextEncoder
    },
    TextDecoder: {
      value: TextDecoder
    }

});
