export declare function concatArrays(...arrays: Uint8Array[]): Uint8Array;
export declare function randomBytes(n: number): Uint8Array;
export declare function b64Encode(bytes: Uint8Array, uriSafe?: boolean): string;
export declare function b64Decode(str: string): Uint8Array;
