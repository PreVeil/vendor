import { PVCrypto, PVCryptoUsage, KeyBytes } from './pv-crypto';
export declare class NaclCryptoClass implements PVCrypto {
    constructor();
    readonly ivLength: number;
    readonly tagLength: number;
    generateSymmKey(): Promise<KeyBytes>;
    generateAsymmKey(usage: PVCryptoUsage, key?: Uint8Array): Promise<[KeyBytes, KeyBytes]>;
    symmetricEncrypt(key: KeyBytes, iv: Uint8Array, plaintext: Uint8Array): Promise<[Uint8Array, Uint8Array]>;
    symmetricDecrypt(key: KeyBytes, iv: Uint8Array, tag: Uint8Array, ciphertext: Uint8Array): Promise<Uint8Array>;
    sharedSecret(privateKey: KeyBytes, publicKey: KeyBytes, _useFipsDerivation?: boolean): Promise<Uint8Array>;
    boxEncrypt(privateKey: KeyBytes, publicKey: KeyBytes, plaintext: Uint8Array, _useFipsDerivation?: boolean): Promise<Uint8Array>;
    boxDecrypt(privateKey: KeyBytes, publicKey: KeyBytes, encryptedResult: Uint8Array, _useFipsDerivation?: boolean): Promise<Uint8Array>;
    hybridEncrypt(publicKey: KeyBytes, plaintext: Uint8Array, _useFipsDerivation?: boolean): Promise<Uint8Array>;
    hybridDecrypt(privateKey: KeyBytes, ciphertext: Uint8Array, _useFipsDerivation?: boolean, publicKey?: KeyBytes): Promise<Uint8Array>;
    sign(seed: KeyBytes, message: Uint8Array): Promise<Uint8Array>;
    publicKeyFromPrivate(privateKey: KeyBytes, usage: PVCryptoUsage): Promise<KeyBytes>;
    verify(publicKey: KeyBytes, message: Uint8Array, signature: Uint8Array): Promise<boolean>;
}
export declare const NaclCrypto: NaclCryptoClass;
