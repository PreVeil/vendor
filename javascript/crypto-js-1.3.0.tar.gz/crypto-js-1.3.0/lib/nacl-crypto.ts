import { PVCrypto, PVCryptoUsage, KeyBytes } from './pv-crypto';
import { concatArrays, randomBytes } from './util';
import * as nacl from 'tweetnacl';
import * as nacl_sealedbox from 'tweetnacl-sealedbox-js';

export class NaclCryptoClass implements PVCrypto {

    constructor() {}

    get ivLength() : number { return 24; }
    get tagLength() : number { return 16; }

    async generateSymmKey(): Promise<KeyBytes> {
        return randomBytes(32);
    }

    async generateAsymmKey(usage: PVCryptoUsage): Promise<[KeyBytes, KeyBytes]> {
        const entropy = randomBytes(32);
        if (usage === PVCryptoUsage.ENCRYPT) {
            const pair = nacl.box.keyPair.fromSecretKey(entropy);
            return [pair.secretKey, pair.publicKey];
        } else {
            const pair = nacl.sign.keyPair.fromSeed(entropy);
            return [entropy, pair.publicKey];
        }
    }

    async symmetricEncrypt(key: KeyBytes, iv: Uint8Array, plaintext: Uint8Array) : Promise<[Uint8Array, Uint8Array]> {
        let result = nacl.secretbox(plaintext, iv, key);
        // Return ciphertext, tag
        return [result.slice(16), result.slice(0, 16)];
    }

    async symmetricDecrypt(key: KeyBytes, iv: Uint8Array, tag: Uint8Array, ciphertext: Uint8Array) : Promise<Uint8Array> {
        return nacl.secretbox.open(concatArrays(tag, ciphertext), iv, key);
    }

    async sharedSecret(privateKey: KeyBytes, publicKey: KeyBytes) : Promise<Uint8Array> {
        return nacl.box.before(publicKey, privateKey);
    }

    async boxEncrypt(privateKey: KeyBytes, publicKey: KeyBytes, plaintext: Uint8Array) : Promise<Uint8Array> {
        let nonce = randomBytes(nacl.box.nonceLength);
        let ciphertext = nacl.box(plaintext, nonce, publicKey, privateKey);
        return concatArrays(nonce, ciphertext);
    }

    async boxDecrypt(privateKey: KeyBytes, publicKey: KeyBytes, encryptedResult: Uint8Array) : Promise<Uint8Array> {

        let nonce = encryptedResult.slice(0, nacl.box.nonceLength);
        let ciphertext = encryptedResult.slice(nacl.box.nonceLength);
        return nacl.box.open(ciphertext, nonce, publicKey, privateKey);
    }

    async hybridEncrypt(publicKey: KeyBytes, plaintext: Uint8Array) : Promise<Uint8Array> {
        return nacl_sealedbox.seal(plaintext, publicKey);
    }

    async hybridDecrypt(privateKey: KeyBytes, ciphertext: Uint8Array, publicKey?: KeyBytes) : Promise<Uint8Array> {
        publicKey = publicKey || await this.publicKeyFromPrivate(privateKey, PVCryptoUsage.ENCRYPT);
        return nacl_sealedbox.open(ciphertext, publicKey, privateKey);
    }

    async sign(seed: KeyBytes, message: Uint8Array) : Promise<Uint8Array> {
        const pair = nacl.sign.keyPair.fromSeed(seed);
        return nacl.sign.detached(message, pair.secretKey);
    }

    async publicKeyFromPrivate(privateKey : KeyBytes, usage: PVCryptoUsage) : Promise<KeyBytes> {
        if (usage === PVCryptoUsage.SIGN) {
            return nacl.sign.keyPair.fromSeed(privateKey).publicKey;
        } else {
            return nacl.box.keyPair.fromSecretKey(privateKey).publicKey;
        }
    }

    async verify(publicKey: KeyBytes, message: Uint8Array, signature: Uint8Array): Promise<boolean> {
        return nacl.sign.detached.verify(message, signature, publicKey);
    }
}
export const NaclCrypto = new NaclCryptoClass();
