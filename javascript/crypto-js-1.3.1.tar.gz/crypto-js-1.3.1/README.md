# crypto-js

Scratch repository for JavaScript implementation of our crypto core, mostly backed by WebCryptography.


## Development

Install the dependencies via `npm ci`. (Avoid using `npm install` as it causes changes to `package-lock.json` unless you are installing an individual new package `npm install ${package}`).



`package.json` scripts have some useful development entry points `npm run ${command}`

### Run tests
- `npm run test`

### Run linter
- `npm run lint`


### Publish a new Github release
- `npm run release`
