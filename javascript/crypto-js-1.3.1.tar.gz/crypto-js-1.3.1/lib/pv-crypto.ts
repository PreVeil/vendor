export type KeyBytes = Uint8Array;

export interface PVCryptoRNG {
    randomBytes(n : number) : Uint8Array;
}

export enum PVCryptoUsage { ENCRYPT = 1, SIGN = 2 }

export interface PVCrypto {
    ivLength: number;
    tagLength: number;

    symmetricEncrypt(key: KeyBytes, iv: Uint8Array, plaintext: Uint8Array) : PromiseLike<[Uint8Array, Uint8Array]>;
    symmetricDecrypt(key: KeyBytes, iv: Uint8Array, tag: Uint8Array, ciphertext: Uint8Array) : PromiseLike<Uint8Array>;

    generateSymmKey() : PromiseLike<KeyBytes>;
    generateAsymmKey(usage: PVCryptoUsage, key?: Uint8Array) : PromiseLike<[KeyBytes, KeyBytes]>;
    publicKeyFromPrivate(privateKey : KeyBytes, usage: PVCryptoUsage) : PromiseLike<KeyBytes>;

    sharedSecret(privateKey: KeyBytes, publicKey: KeyBytes) : PromiseLike<Uint8Array>;
    boxEncrypt(privateKey: KeyBytes, publicKey: KeyBytes, plaintext: Uint8Array) : PromiseLike<Uint8Array>;
    boxDecrypt(privateKey: KeyBytes, publicKey: KeyBytes, ciphertext: Uint8Array) : PromiseLike<Uint8Array>;
    hybridEncrypt(publicKey: KeyBytes, plaintext: Uint8Array) : PromiseLike<Uint8Array>;
    hybridDecrypt(privateKey: KeyBytes, ciphertext: Uint8Array, publicKey?: KeyBytes) : PromiseLike<Uint8Array>;

    sign(privateKey: KeyBytes, message: Uint8Array) : PromiseLike<Uint8Array>;
    verify(publicKey: KeyBytes, message: Uint8Array, signature: Uint8Array) : PromiseLike<boolean>;
}
