import * as nacl from 'tweetnacl';
import { PVCrypto, PVCryptoUsage, KeyBytes } from './pv-crypto';
import { concatArrays, randomBytes, b64Decode, b64Encode } from './util';

const elliptic = require('elliptic'),
      ecP256Context = new elliptic.ec('p256'),
      P256Curve = elliptic.curves.p256.curve,
      webcrypto = crypto.subtle,
      AES_TAG_LEN = 16,
      AES_IV_LEN = 12,
      PUB_KEY_LEN = 65;

export class FipsCryptoClass implements PVCrypto {

    constructor() {}

    get ivLength() : number { return AES_IV_LEN; }
    get tagLength() : number { return AES_TAG_LEN; }

    async generateSymmKey() : Promise<Uint8Array> {
        return webcrypto.generateKey(
                {name: 'AES-GCM', length: 256}, true, ['encrypt', 'decrypt'])
            .then(k => webcrypto.exportKey('raw', k))
            .then(k => new Uint8Array(k));
    }

    async generateAsymmKey(usage: PVCryptoUsage) : Promise<[KeyBytes, KeyBytes]> {
        if (usage === PVCryptoUsage.ENCRYPT) {
            return this.generateEncryptionKey();
        } else {
            return this.generateSigningKey();
        }
    }

    async symmetricEncrypt(key: KeyBytes, iv: Uint8Array, plaintext: Uint8Array) : Promise<[Uint8Array, Uint8Array]> {
        let k = await webcrypto.importKey('raw', key, 'AES-GCM', false, ['encrypt']);
        let opts = { name: 'AES-GCM', iv: iv };
        let result = new Uint8Array(await webcrypto.encrypt(opts, k, plaintext));

        // Return [ciphertext, tag]
        return [result.slice(0, -AES_TAG_LEN), result.slice(-AES_TAG_LEN)];
    }

    async symmetricDecrypt(key: KeyBytes, iv: Uint8Array, tag: Uint8Array, ciphertext: Uint8Array) : Promise<Uint8Array> {
        let k = await webcrypto.importKey('raw', key, 'AES-GCM', false, ['decrypt']);
        let opts = { name: 'AES-GCM', iv: iv };
        return new Uint8Array(await webcrypto.decrypt(opts, k, concatArrays(ciphertext, tag)));
    }

    async sharedSecret(privateKey: KeyBytes, publicKey: KeyBytes) : Promise<Uint8Array> {
        // Can't use nacl.box.before() here, because that includes a hash step that is both redundant
        // and would not match of the output of the C implementation.
        let naclSecret = nacl.scalarMult(this.curve25519Part(privateKey), this.curve25519Part(publicKey));

        let p256PrivKey = await this.importP256PrivateKey(this.p256Part(privateKey), ['deriveBits']);
        let p256PubKey = await this.importP256PublicKey(this .p256Part(publicKey), []);
        let deriveParams = { name: 'ECDH', namedCurve: 'P-256', public: p256PubKey };
        let p256Secret = new Uint8Array(await webcrypto.deriveBits(deriveParams, p256PrivKey, 256));

        let combinedSecret = concatArrays(naclSecret, p256Secret);
        return new Uint8Array(await webcrypto.digest({name: 'SHA-256'}, combinedSecret));
    }

    async boxEncrypt(privateKey: KeyBytes, publicKey: KeyBytes, plaintext: Uint8Array) : Promise<Uint8Array> {
        let derivedKey = await this.sharedSecret(privateKey, publicKey);
        let iv = randomBytes(AES_IV_LEN);

        let [ciphertext, tag] = await this.symmetricEncrypt(derivedKey, iv, plaintext);
        return concatArrays(iv, tag, ciphertext);
    }

    async boxDecrypt(privateKey: KeyBytes, publicKey: KeyBytes, encryptedResult: Uint8Array) : Promise<Uint8Array> {
        let iv = encryptedResult.slice(0, AES_IV_LEN);
        let tag = encryptedResult.slice(AES_IV_LEN, AES_IV_LEN + AES_TAG_LEN);
        let ciphertext = encryptedResult.slice(AES_IV_LEN + AES_TAG_LEN);

        let derivedKey = await this.sharedSecret(privateKey, publicKey);
        return await this.symmetricDecrypt(derivedKey, iv, tag, ciphertext);
    }

    async hybridEncrypt(publicKey: KeyBytes, plaintext: Uint8Array) : Promise<Uint8Array> {
        let [ephemeralPrivateKey, ephemeralPublicKey] = await this.generateEncryptionKey();
        // Yes, we're deserializing the private key again right away.
        let symmetricKey = await this.sharedSecret(ephemeralPrivateKey, publicKey);
        let iv = new Uint8Array(AES_IV_LEN).fill(0);

        let [ciphertext, tag] = await this.symmetricEncrypt(symmetricKey, iv, plaintext);
        return concatArrays(ephemeralPublicKey, tag, ciphertext);
    }

    async hybridDecrypt(privateKey: KeyBytes, encryptedResult: Uint8Array) : Promise<Uint8Array> {
        let ephemeralPublicKey = encryptedResult.slice(0, PUB_KEY_LEN);
        let tag = encryptedResult.slice(PUB_KEY_LEN, PUB_KEY_LEN + AES_TAG_LEN);
        let ciphertext = encryptedResult.slice(PUB_KEY_LEN + AES_TAG_LEN);
        let symmetricKey = await this.sharedSecret(privateKey, ephemeralPublicKey);
        let iv = new Uint8Array(AES_IV_LEN).fill(0);

        return this.symmetricDecrypt(symmetricKey, iv, tag, ciphertext);
    }

    async generateEncryptionKey() : Promise<[KeyBytes, KeyBytes]> {
        let curve25519Key = nacl.box.keyPair();
        let [p256Private, p256Public] = await this.generateP256Key(PVCryptoUsage.ENCRYPT);

        return [concatArrays(curve25519Key.secretKey, p256Private),
                concatArrays(curve25519Key.publicKey, p256Public)];
    }

    async generateSigningKey() : Promise<[KeyBytes, KeyBytes]> {
        let curve25519Seed = randomBytes(32);
        let curve25519Key = nacl.sign.keyPair.fromSeed(curve25519Seed);
        let [p256Private, p256Public] = await this.generateP256Key(PVCryptoUsage.SIGN);

        return [concatArrays(curve25519Seed, p256Private),
                concatArrays(curve25519Key.publicKey, p256Public)];
    }

    async generateP256Key(usage: PVCryptoUsage) : Promise<[KeyBytes, KeyBytes]> {
        // Indicates a key format of a 32-byte x-coordinate followed by a 32-byte y-coordinate
        const prefix = new Uint8Array([0x04]);
        let key;

        // P-256 keys are the same for signing and encryption, but let's still do this properly
        if (usage === PVCryptoUsage.ENCRYPT) {
            key = await webcrypto.generateKey(
                                {name: 'ECDH', namedCurve: 'P-256'},
                                true, ['deriveBits']);
        } else {
            key = await webcrypto.generateKey(
                                {name: 'ECDSA', namedCurve: 'P-256'},
                                true, ['sign']);
        }
        let jwkKey = await webcrypto.exportKey('jwk', key.privateKey);
        let privateKeyBytes = b64Decode(jwkKey.d);
        // The WebCrypto API generates uncompressed public key coordinates, but our external key represenation
        // is compressed (33 bytes). So we use the elliptic library to do the conversion.
        let uncompressedPublicKey = concatArrays(prefix, b64Decode(jwkKey.x), b64Decode(jwkKey.y));
        let publicKeyBytes = P256Curve.decodePoint(uncompressedPublicKey).encodeCompressed();

        return [privateKeyBytes, new Uint8Array(publicKeyBytes)];
    }

    async sign(privateKey: KeyBytes, message: Uint8Array) : Promise<Uint8Array> {
        // Our external format here is a 32 byte seed value that gets expanded into a 64 byte key.
        let naclKey = nacl.sign.keyPair.fromSeed(this.curve25519Part(privateKey));
        let naclSig = nacl.sign.detached(message, naclKey.secretKey);

        let p256Key = await this.importP256PrivateKey(this.p256Part(privateKey), ['sign']);
        let signature = await webcrypto.sign({name: 'ECDSA', hash: {name: 'SHA-256'}}, p256Key, message);

        return concatArrays(naclSig, new Uint8Array(signature));
    }

    async verify(publicKey: KeyBytes, message: Uint8Array, signature: Uint8Array) : Promise<boolean> {
        // Signature format is a 64 byte NaCl signature followed by a 64 byte P-256 signature, both
        // in simple (r,s) format.
        let naclSig = signature.slice(0, 64);
        if (!nacl.sign.detached.verify(message, naclSig, this.curve25519Part(publicKey))) {
            return false;
        }

        let p256Key = await this.importP256PublicKey(this.p256Part(publicKey), ['verify']);
        let p256Sig = signature.slice(64);
        return webcrypto.verify({name: 'ECDSA', hash: {name: 'SHA-256'}}, p256Key, p256Sig, message);
    }

    async publicKeyFromPrivate(privateKey : KeyBytes, usage: PVCryptoUsage) : Promise<KeyBytes> {
        let curve25519Bytes = this.curve25519Part(privateKey);
        let curve25519Key;

        if (usage === PVCryptoUsage.SIGN) {
            curve25519Key = nacl.sign.keyPair.fromSeed(curve25519Bytes).publicKey;
        } else {
            curve25519Key = nacl.box.keyPair.fromSecretKey(curve25519Bytes).publicKey;
        }

        let p256PrivKey = ecP256Context.keyFromPrivate(this.p256Part(privateKey));
        let p256Key = p256PrivKey.getPublic(true, 'binary');

        return concatArrays(curve25519Key, p256Key);
    }

    // First 32 bytes are Curve25519
    curve25519Part(keyBytes: KeyBytes) : Uint8Array {
        return keyBytes.slice(0, 32);
    }

    // Second part (after 32 bytes) is P-256
    p256Part(keyBytes: KeyBytes) : Uint8Array {
        return keyBytes.slice(32);
    }

    async importP256PrivateKey(keyBytes : KeyBytes, usages : string[]) : Promise<CryptoKey> {
        let privKey = ecP256Context.keyFromPrivate(keyBytes);
        // The Crypto API requires the public key coordinates to be present (uncompressed) when
        // importing a private key. We use the elliptic library to derive these.
        let pubKeyPoint = privKey.getPublic();

        return await webcrypto.importKey(
            'jwk',
            {
                kty: 'EC',
                crv: 'P-256',
                x: b64Encode(pubKeyPoint.getX().toArrayLike(Uint8Array), true),
                y: b64Encode(pubKeyPoint.getY().toArrayLike(Uint8Array), true),
                d: b64Encode(keyBytes, true)
            },
            {name: this.algorithmName(usages), namedCurve: 'P-256'},
            false,
            usages
        );
    }

    async importP256PublicKey(keyBytes: KeyBytes, usages : string[]) : Promise<CryptoKey> {
        // Use the elliptic library to expand compressed coords to uncompressed.
        let point = P256Curve.decodePoint(keyBytes);

        return webcrypto.importKey(
            'jwk',
            {
                kty: 'EC',
                crv: 'P-256',
                x: b64Encode(point.getX().toArrayLike(Uint8Array), true),
                y: b64Encode(point.getY().toArrayLike(Uint8Array), true)
            },
            {name: this.algorithmName(usages), namedCurve: 'P-256'},
            false,
            usages
        );
    }

    algorithmName(usages: string[]) : string {
        return usages.includes('sign') || usages.includes('verify') ? 'ECDSA' : 'ECDH';
    }
}

export const FipsCrypto = new FipsCryptoClass();
