const ENCODED_VALS_BASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' +
                          'abcdefghijklmnopqrstuvwxyz' +
                          '0123456789',
      ENCODED_VALS = ENCODED_VALS_BASE + '+/=',
      ENCODED_VALS_WEBSAFE = ENCODED_VALS_BASE + '-_.',
      charToByteMap_ = {},
      byteToCharMap_ = {},
      byteToCharMapWebSafe_ = {};

for (var i = 0; i < ENCODED_VALS.length; ++i) {
    byteToCharMap_[i] = ENCODED_VALS.charAt(i);
    charToByteMap_[byteToCharMap_[i]] = i;
    byteToCharMapWebSafe_[i] = ENCODED_VALS_WEBSAFE.charAt(i);

    // remove `=` rather than replacing w `.`
    if (ENCODED_VALS_WEBSAFE.charAt(i) === '.') {
      byteToCharMapWebSafe_[i] = '';
    }

    // Be forgiving when decoding and correctly decode both encodings.
    if (i >= ENCODED_VALS_BASE.length) {
        charToByteMap_[ENCODED_VALS_WEBSAFE.charAt(i)] = i;
    }
}

export function concatArrays(...arrays: Uint8Array[]) : Uint8Array {
    let arr = new Uint8Array(arrays.reduce((n, a) => n + a.length, 0));
    let i = 0;
    arrays.forEach(a => {
        arr.set(a, i);
        i += a.length;
    });
    return arr;
}

// 'crypto.getRandomValues' api can't create randoms bigger that 2^16
const maxBytesOfEntropy = 2 ** 16;
export function randomBytes(n : number): Uint8Array {
    const arr = new Uint8Array(n);
    const chunkCount = Math.floor(n / maxBytesOfEntropy);
    for (let i = 0 ; i < chunkCount + 1 ; ++i) {
      const a = new Uint8Array(i === chunkCount ? n % maxBytesOfEntropy : maxBytesOfEntropy);
      crypto.getRandomValues(a);
      arr.set(a, i * maxBytesOfEntropy);
    }
    return arr;
}

// https://github.com/google/closure-library/blob/master/closure/goog/string/internal.js#L98
function isEmptyOrWhitespace(str: string) {
    // testing length == 0 first is actually slower in all browsers (about the
    // same in Opera).
    // Since IE doesn't include non-breaking-space (0xa0) in their \s character
    // class (as required by section 7.2 of the ECMAScript spec), we explicitly
    // include it in the regexp to enforce consistent cross-browser behavior.
    return /^[\s\xa0]*$/.test(str);
}

function decodeStringInternal(input, pushByte) {
    var nextCharIndex = 0;

    function getByte(default_val) {
        while (nextCharIndex < input.length) {
        var ch = input.charAt(nextCharIndex++);
        var b = charToByteMap_[ch];
        if (b != null) {
            return b;  // Common case: decoded the char.
        }
        if (!isEmptyOrWhitespace(ch)) {
            throw new Error('Unknown base64 encoding at char: ' + ch);
        }
        // We encountered whitespace: loop around to the next input char.
        }
        return default_val;  // No more input remaining.
    }

    while (true) {
        var byte1 = getByte(-1);
        var byte2 = getByte(0);
        var byte3 = getByte(64);
        var byte4 = getByte(64);

        // The common case is that all four bytes are present, so if we have byte4
        // we can skip over the truncated input special case handling.
        if (byte4 === 64) {
        if (byte1 === -1) {
            return;  // Terminal case: no input left to decode.
        }
        // Here we know an intermediate number of bytes are missing.
        // The defaults for byte2, byte3 and byte4 apply the inferred padding
        // rules per the public API documentation. i.e: 1 byte
        // missing should yield 2 bytes of output, but 2 or 3 missing bytes yield
        // a single byte of output. (Recall that 64 corresponds the padding char).
        }

        var outByte1 = (byte1 << 2) | (byte2 >> 4);
        pushByte(outByte1);

        if (byte3 !== 64) {
        var outByte2 = ((byte2 << 4) & 0xF0) | (byte3 >> 2);
        pushByte(outByte2);

        if (byte4 !== 64) {
            var outByte3 = ((byte3 << 6) & 0xC0) | byte4;
            pushByte(outByte3);
        }
        }
    }
}

  // https://github.com/google/closure-library/blob/master/closure/goog/crypt/base64.js#L124
  export function b64Encode(bytes: Uint8Array, uriSafe: boolean = false): string {
    var byteToCharMap = uriSafe ? byteToCharMapWebSafe_ : byteToCharMap_;
    var output = [];

    for (var i = 0; i < bytes.length; i += 3) {
      var byte1 = bytes[i];
      var haveByte2 = i + 1 < bytes.length;
      var byte2 = haveByte2 ? bytes[i + 1] : 0;
      var haveByte3 = i + 2 < bytes.length;
      var byte3 = haveByte3 ? bytes[i + 2] : 0;

      var outByte1 = byte1 >> 2;
      var outByte2 = ((byte1 & 0x03) << 4) | (byte2 >> 4);
      var outByte3 = ((byte2 & 0x0F) << 2) | (byte3 >> 6);
      var outByte4 = byte3 & 0x3F;

      if (!haveByte3) {
        outByte4 = 64;

        if (!haveByte2) {
          outByte3 = 64;
        }
      }

      output.push(
          byteToCharMap[outByte1], byteToCharMap[outByte2],
          byteToCharMap[outByte3], byteToCharMap[outByte4]);
    }

    return output.join('');
  }

  // https://github.com/google/closure-library/blob/master/closure/goog/crypt/base64.js#L255
  export function b64Decode(str: string): Uint8Array {
    var len = str.length;
    // Check if there are trailing '=' as padding in the b64 string.
    var placeholders = 0;
    if (str[len - 2] === '=') {
      placeholders = 2;
    } else if (str[len - 1] === '=') {
      placeholders = 1;
    }
    var output = new Uint8Array(Math.ceil(len * 3 / 4) - placeholders);
    var outLen = 0;
    function pushByte(b) {
      output[outLen++] = b;
    }

    decodeStringInternal(str, pushByte);

    return output.subarray(0, outLen);
  }
